package pl.com.kamil.wizytowkaaletymrazembezmenubotosyf;

import androidx.lifecycle.ViewModel;

class MainActivityViewModel extends ViewModel {
    public String imienazwisko = "";
    public String zawod = "";
    public String nrtelefonu = "";
    public String email="";
    public String stronainternetowa = "";


}
